
package adventuresearch;

import javax.swing.JOptionPane;

public class Usuario {
private String nombreUsuario;
private String correoUsuario;
private String contraseñaUsuario;
private String pais;
private int edad;
private String genero;

public void CRUD(String nombreUsuario, String correoUsuario, String contraseñaUsuario, String pais, int edad, String genero){
System.out.println("Nombre de usuario: " + nombreUsuario + " Correo de usuario: " + correoUsuario + " Contraseña de usuario (esta información sólo puede verla usted): " + contraseñaUsuario + " El país del usuario es: " + pais + " La edad del usuario es: " + edad + " Y el género del usuario es: " + genero);
}

public void realizarLogin(String correoUsuario, String contraseñaUsuario, String correoLogin, String contraseñaLogin){
if(correoLogin.equals(correoUsuario) && contraseñaLogin.equals(contraseñaUsuario)){
System.out.println("Ha ingresado correctamente a su cuenta");
}else{
System.out.println("Los datos digitados no coinciden con los datos de su cuenta");
}}
}    

