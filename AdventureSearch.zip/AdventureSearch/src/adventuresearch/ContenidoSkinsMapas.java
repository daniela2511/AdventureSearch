
package adventuresearch;

import javax.swing.JOptionPane;

public class ContenidoSkinsMapas {
private String nombreCreador;    
private String fechaCreacion;
private String descripcion;

public void CRUD(String nombreCreador, String fechaCreacion, String descripcion){
System.out.println("El nombre del creador del skin o mapa es: " + nombreCreador + " su fecha de creación es: " + fechaCreacion + " y la descripción del contenido es: " + descripcion);
}
}
