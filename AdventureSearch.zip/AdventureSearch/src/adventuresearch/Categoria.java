
package adventuresearch;

public class Categoria {
private String tipoJuego;

public void mostrarCategoria(String tipoJuego){
System.out.println("La categoría de la skin o del mapa es: " + tipoJuego);
}
}
