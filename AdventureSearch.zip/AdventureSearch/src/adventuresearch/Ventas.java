
package adventuresearch;

public class Ventas {
private String metodoPago;
private String skinOMapa;
private int monto;

public void ingresarMetodoPago(String metodoPago){
System.out.println("El método de pago que se va a implementar será: " + metodoPago);
}

public void pagar(int monto, String skinOMapa){
System.out.println("El pago de " + skinOMapa + " de " + monto + "$ ha sido realizado");
}
}
