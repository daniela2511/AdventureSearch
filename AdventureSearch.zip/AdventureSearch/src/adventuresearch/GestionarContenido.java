
package adventuresearch;

import javax.swing.JOptionPane;

public class GestionarContenido {
private String comentarios;
private String meGusta;
private int descargar;
private String compartir;

public void realizarComentarios(String comentarios){
comentarios = JOptionPane.showInputDialog("Escriba el comentario que desea hacer");
System.out.println("Has comentado: " + comentarios);
}

public void darMeGusta(){
System.out.println("Has indicado que te gusta 👍");
}

public void descargar(int descargar){
System.out.println("------ ¿Desea descargar éste mapa? ------");
System.out.println("------ 1. Sí ------");
System.out.println("------ 2. No ------");
descargar = Integer.parseInt(JOptionPane.showInputDialog("------ Digite su respuesta ------"));
if(descargar == 1){
System.out.println("Se ha descargar el mapa con éxito");
}
}

public void compartir(String compartir){
compartir = JOptionPane.showInputDialog("Escribe en qué redes quieres compartir el mapa de aventuras o skin");
System.out.println("Se ha compartido con éxito en " + compartir);
}
}
