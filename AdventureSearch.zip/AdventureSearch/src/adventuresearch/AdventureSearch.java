package adventuresearch;

import javax.swing.JOptionPane;

public class AdventureSearch {

    public static void main(String[] args) {
        Usuario us = new Usuario();
        ContenidoSkinsMapas csm = new ContenidoSkinsMapas();
        Categoria cc = new Categoria();
        GestionarContenido gc = new GestionarContenido();
        Ventas vv = new Ventas();
        
        //De clase Ventas
        String metodoPago;
        String skinOMapa;
        int monto = 100000;
        //De clase GestionarContenido
        String comentarios = "";
        int descargar = 0;
        String compartir = "";
        //De clase categoría
        String tipoJuego = "Terror";
        //De clase ContenidoSkinsMapas
        String nombreCreador = "Brayan Camilo Annear";
        String fechaCreacion = "20/04/2020";
        String descripcion = "Mapa de aventuras de terror + skin del juego de terror";
        //De clase usuario
        String nombreUsuario;
        String pais;
        int edad;
        String genero;
        String correoUsuario;
        String contraseñaUsuario;
        String correoLogin;
        String contraseñaLogin;
        //Del código
        int vecesMenu;
        int acum = 0;
        
            System.out.println("------ CREAR CUENTA ------");
            nombreUsuario = JOptionPane.showInputDialog("Digite su nombre");
            pais = JOptionPane.showInputDialog("Digite su país");
            edad = Integer.parseInt(JOptionPane.showInputDialog("Digite su edad"));
            genero = JOptionPane.showInputDialog("Digite su género");
            correoUsuario = JOptionPane.showInputDialog("Digite su nuevo correo de la cuenta");
            contraseñaUsuario = JOptionPane.showInputDialog("Digite su nueva contraseña de la cuenta");
            us.CRUD(nombreUsuario, correoUsuario, contraseñaUsuario, pais, edad, genero);
            
        vecesMenu = Integer.parseInt(JOptionPane.showInputDialog("Digite cuántas veces desea usar el menú"));

        while (acum != vecesMenu) {

            acum = acum + 1;
            System.out.println("------ CUENTA ------");
            System.out.println("------ 1. Realizar login ------");
            System.out.println("------ 2. Ver algo del contenido ------");
            System.out.println("------ 3. Ver categoría del contenido ------");
            System.out.println("------ 4. Gestionar contenido ------");
            System.out.println("------ 5. Realizar una compra ------");
            System.out.println("------ 6. Salir ------");
            int opc = Integer.parseInt(JOptionPane.showInputDialog("------ Digite el número de opción ------"));

            if (opc == 6) {
                System.out.println("Saliendo...");
                break;
            } else{
            switch(opc){
                case 1:
                correoLogin = JOptionPane.showInputDialog("Digite su correo");
                contraseñaLogin = JOptionPane.showInputDialog("Digite su contraseña");
                us.realizarLogin(correoUsuario, contraseñaUsuario, correoLogin, contraseñaLogin);
                break;
                case 2:
                csm.CRUD(nombreCreador, fechaCreacion, descripcion);
                break;
                case 3:
                cc.mostrarCategoria(tipoJuego);
                break;
                case 4:
                int veces;
                int acum2 = 0;
                veces = Integer.parseInt(JOptionPane.showInputDialog("Digite cuántas veces desea gestionar el contenido"));
                while(acum2 <= veces){
                acum2 = acum2 + 1;
                System.out.println("------ GESTIONAR CONTENIDO ------");
                System.out.println("------ 1. Realizar un comentario ------");
                System.out.println("------ 2. Dar me gusta ------");
                System.out.println("------ 3. Descargar ------");
                System.out.println("------ 4. Compartir ------");
                int opc2 = Integer.parseInt(JOptionPane.showInputDialog("Digite su opción"));
                if(opc2 == 1){
                gc.realizarComentarios(comentarios);
                }else if(opc2 == 2){
                gc.darMeGusta();
                }else if(opc2 == 3){
                gc.descargar(descargar);
                }else if(opc2 == 4){
                gc.compartir(compartir);
                }}
                break;
                case 5:
                skinOMapa = JOptionPane.showInputDialog("Digite el nombre de la skin o del mapa de aventuras");    
                metodoPago = JOptionPane.showInputDialog("Digite el método de pago que usará");
                vv.ingresarMetodoPago(metodoPago);
                vv.pagar(monto, skinOMapa);
                break;
            }   
            }
        }
    }
}
